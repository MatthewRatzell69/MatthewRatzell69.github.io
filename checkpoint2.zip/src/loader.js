import * as main from "./main.js";
import "./sw-nav.js";
import "./sw-footer.js";
